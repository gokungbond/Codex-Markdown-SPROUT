# Sprout LMS development

Use this file as the project entry point. See [Sprout Development Skills](SPROUT-DEVELOPMENT-SKILLS.md) for reference implementations, the testing matrix, and known baseline issues. Check the current code when older documentation and implementation differ.

## Select the relevant skills

| Task | Skill |
| --- | --- |
| Add or organize routes, modules, layouts, or shared code | `$sprout-architecture` |
| Build forms, schemas, edit hydration, or payload mappers | `$sprout-forms` |
| Build tables, dialogs, confirmations, sheets, or reusable controls | `$sprout-ui` |
| Integrate endpoints or change auth, caching, or state ownership | `$sprout-api-state` |
| Simplify existing code while preserving behavior | `$sprout-refactoring` |
| Diagnose a reported issue or regression | `$sprout-debugging` |
| Choose and run validation checks | `$sprout-quality` |
| Review a completed integration or security-sensitive change | [`$post-implementation-review`](.agents/skills/post-implementation-review/SKILL.md) |

Load the matching skills from [`.agents/skills`](.agents/skills). The guide links to each `SKILL.md` and its source references.

## Project conventions

- Keep route orchestration in `src/app`, domain UI and hooks in `src/features`, reusable UI in `src/components`, request logic in `src/services`, and API contracts in `src/types`. Follow the nearest feature's folder structure and use the `@/` alias for cross-area imports.
- Use strict TypeScript. Use PascalCase for components, camelCase for functions and hooks, and kebab-case for new filenames. Reuse existing controls, utilities, and hooks before adding an abstraction.
- Route backend calls through the existing services and Axios client. Use the query-key factories in `src/constants/query-keys.ts` and confirm which list and detail readers need to refresh after a mutation. Keep server data in TanStack Query, form data in React Hook Form, and transient UI state near its owner.
- Use React Hook Form with Zod. Map API records to form defaults and validated values to request payloads. Verify edit hydration, same-record reopen, and preservation of dirty fields during background refreshes.
- Put each new purpose-specific modal or dialog in its own feature component file. The parent imports it and passes its open state and selected data. Reuse `AppModal`, confirmation wrappers, `Sheet`, and `DataTable` where their behavior fits. For server pagination, confirm the conversion from zero-based table indexes to one-based API pages.

## Development and validation

After implementation and before declaring the task complete, run `$post-implementation-review` for changes that add or modify LMS API, third-party API, service, or SDK integrations, or AWS S3 uploads, signed URLs, downloads, or streaming. Also run it for changes involving authentication, authorization, course access, assessment integrity, or sensitive user information. For presentation-only and internal component changes, use basic `$sprout-quality` verification and review any identifiable frontend security risk at the scope of that risk.

For DataTable work, compare neighboring admin pages and their feature `columns.tsx` files. Keep column definitions and row rendering in the feature file. Let the page own queries, filters, pagination, and dialog state.

For row-level actions, follow the neighboring admin tables' ellipsis dropdown pattern. Keep permissions and row-specific eligibility checks on individual menu items.

1. Analyze the requirements and trace the affected workflow from its normal entry point. For larger changes, outline the smallest implementation and how to verify it.
2. Before writing code, consult the applicable skills, the closest reference implementation and shared callers. Search relevant sections of the development guide and the applicable skills' `references/reusable-findings.md` files when present. Read matching entries only. Reuse verified solutions after checking compatibility with current requirements, code and architecture. Continue the applicable review and testing.
3. Implement the requested behavior. Preserve existing route, component and API contracts unless the task changes them.
4. Review the diff and apply the review conditions above. Address findings within the authorized scope.
5. Verify the implementation and any review fixes. Run `npm run typecheck` and `npm run lint` as applicable. Use `npm run lint -- path/to/file` for a focused check and `npm.cmd` in PowerShell if needed. Exercise the affected workflow when local dependencies are available, including loading, failure, retry, create and edit, request payloads and cache refresh where relevant. The checkout has no configured automated test suite.
6. After verification, follow the [retention guidance](.agents/skills/post-implementation-review/SKILL.md#retain-reusable-findings) when review identifies a meaningful reusable finding.
7. Report changed files, existing patterns reused, findings retained, checks actually run, results and remaining verification gaps.
