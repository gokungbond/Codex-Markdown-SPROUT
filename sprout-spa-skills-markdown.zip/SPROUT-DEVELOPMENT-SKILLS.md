# Sprout development skills

The skills live in this repository under [`.agents/skills`](.agents/skills). Open the repository in a new Codex session and invoke a skill by name, such as `$sprout-forms`. Each skill uses paths relative to this repository.

## Inventory

| Skill | Purpose | Use when | Reference modules |
| --- | --- | --- | --- |
| [`$sprout-architecture`](.agents/skills/sprout-architecture/SKILL.md) | Route and feature boundaries, imports, reusable code | Adding a page, module, or shared abstraction | [Categories page](src/app/admin/categories/page.tsx), [Admin shell](src/components/layout/admin-shell.tsx), [Courses feature](src/features/courses) |
| [`$sprout-forms`](.agents/skills/sprout-forms/SKILL.md) | React Hook Form, Zod, form types, hydration and payloads | Adding forms or changing validation, dynamic fields, or edit defaults | [User dialog](src/features/users/user-form-dialog.tsx), [Employee form](src/features/employees/forms/employee-form.tsx), [Assessment schema](src/features/courses/dialogs/assessment/schemas/course-assessment-schema.ts) |
| [`$sprout-ui`](.agents/skills/sprout-ui/SKILL.md) | Shared controls, tables, dialogs, confirmations and drawers | Building or changing Sprout interactions | [DataTable](src/components/tables/data-table.tsx), [AppModal](src/components/common/modal.tsx), [AlertConfirm](src/components/common/alert-confirm.tsx), [Mobile sidebar sheet](src/components/ui/sidebar.tsx) |
| [`$sprout-api-state`](.agents/skills/sprout-api-state/SKILL.md) | Axios transport, request/response types, cache and state ownership | Integrating endpoints, mutations, pagination, uploads, auth, or state synchronization | [Category service](src/services/category.service.ts), [Query keys](src/constants/query-keys.ts), [Upload service](src/services/upload.service.ts), [Course editor](src/features/courses/forms/course-form.tsx) |
| [`$sprout-refactoring`](.agents/skills/sprout-refactoring/SKILL.md) | Small behavior-preserving changes | Extracting, consolidating, removing dead code, or tightening types | [Category mutations](src/features/categories/hooks/use-category-mutations.ts), [User mutations](src/features/users/hooks/use-user-mutations.ts), [Course activities](src/features/courses/forms/components/course-activities-form.tsx) |
| [`$sprout-quality`](.agents/skills/sprout-quality/SKILL.md) | Static checks and regression verification | Planning tests or verifying an implementation | [Scripts](package.json), [TS config](tsconfig.json), [ESLint config](eslint.config.mjs) |
| [`$sprout-debugging`](.agents/skills/sprout-debugging/SKILL.md) | Runtime diagnosis and root-cause tracing | Investigating missing records, overwritten form input, stale state, or validation errors | [Module dialog](src/features/courses/dialogs/module/course-module-form-dialog.tsx), [Query provider](src/providers/query-provider.tsx), [Error handler](src/lib/on-error.tsx) |

## Conventions

- App Router pages compose feature UI and own route-level orchestration. Domain schemas, columns, dialogs, and hooks live in features. Shared controls and layouts live in components, transport in services, and backend contracts in types. Follow the current route and module even when README.md describes an earlier layout.
- Axios services return typed domain data from the API envelope. TanStack Query hooks own server state, key construction and invalidation. UI state stays near its owner. Auth and route guards are client-side. Multipart storage requests use presigned URLs without app credentials.
- React Hook Form and Zod handle form state and validation. Hydrate from explicitly mapped response values and map validated form values into the request contract. Preserve valid edits through unrelated refreshes and verify forced-render dialog reopen behavior.
- Reuse Base UI and shadcn controls, app buttons and inputs, feature-specific dialog components, Sonner feedback, and DataTable. Server tables generally convert the zero-based UI page index to the one-based API page. The shared table sorts the loaded rows. The existing drawer primitive is Sheet. DynamicSheet and a common currency formatter were not found.
- Naming and file placement differ in some older or larger areas. Examples include `schema.ts` versus `schemas.ts`, the courses `hook` directory, and a course form schema imported from landing. These are compatibility details to check when moving code.

## Refactoring opportunities

| Impact | Regression risk | Candidate and verification |
| --- | --- | --- |
| Low | Low | Consolidate the duplicate upload deletion methods after comparing callers and failure handling. |
| Medium | Low to medium | Verify end-of-list behavior in infinite lookups that use an inclusive page bound. Exercise one-page and multi-page results against actual API metadata. |
| High | Medium | Tighten reset boundaries for category and course module editing. Test same-record reopen, record switches, late data, dirty drafts, and replacement-file cancellation. |
| High | Medium | Prioritize mapper/schema regression coverage for employee data and nested course assessments. Include optional arrays, preserved UUIDs, and invalid choices. |
| High | High | Investigate the retained course activity order after save and concurrent invalidation/refetch. Compare draft IDs, PATCH payload, refreshed detail and rendered order. Check add/delete after reordering and behavior on failure. |

## Testing guide

| Change | Checks |
| --- | --- |
| Any TypeScript or JSX change | Run `npm run typecheck` and `npm run lint`. For a focused lint pass use `npm run lint -- path/to/file`. In Windows PowerShell use `npm.cmd` if script execution blocks `npm`. |
| Form or mapper | Test valid and invalid create/edit, same-record reopen, record switch, late data, dirty refetch, optional and nullable values, nested edits, exact payload, and duplicate submit. For edit uploads use disposable local data because the existing replacement handler can delete the old upload before submit. |
| Endpoint, query, or mutation | With a configured local/test API, inspect method, URL, request shape, response envelope, boundaries, role behavior, failure and retry, and refresh of every affected list or detail reader. |
| Table, dialog, or shared control | Exercise loading/empty/error, keyboard and focus, close/confirm, pending actions, pagination/search, and narrow layout. Smoke-test another consumer if shared behavior changed. |
| Route or build behavior | Run `npm run dev` for browser checks. Run `npm run build` when a production compilation check is needed. See [README](README.md) for API configuration and confirm the local environment before testing. |

There is no unit or integration test script, checked-in suite, or configured runner in the inspected checkout. Use targeted browser checks and pure-data fixtures where practical. For future automation, prioritize mapper/schema cases and the create/edit and course-ordering flows.

## Verification

- Seven skill entry points passed YAML parsing, name and description checks, placeholder checks, source-path checks, and skill cross-reference checks. Installed copies were verified by hash. The bundled Python validator requires Python and PyYAML. A working Python executable was unavailable, so the checks used installed Node.js and js-yaml.
- An independent read-only forward test traced the course module edit and course reorder reports through the dialog, upload state, request, cache and render paths. The debugging skill incorporates its findings. Other representative workflows were checked against source implementations. Browser and API-backed workflows were not exercised during skill creation.
- Full ESLint completed with **0 errors and 62 warnings**. Focused ESLint over categories, users, courses, common controls, and tables also exited successfully with `--quiet`.
- `npm run typecheck -- --incremental false` failed on malformed generated files in `.next/dev/types`. A separate read-only TypeScript diagnostic run without the dev-generated declarations reported **7 errors**, covering the competency lookup import, employee address dialog, learning capability form, and Axios config typing. The separate run is diagnostic and does not replace the standard check.
