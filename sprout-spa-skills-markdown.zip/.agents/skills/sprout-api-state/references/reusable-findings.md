# Sprout API state findings

## Omit unchanged legacy course classification in PATCH

**Verified** by SPA schema and payload assertions and inspection of the course update DTO and service. Live API verification was unavailable.

- **Scenario and cause.** Legacy course details can have an unassigned category and no tags. These response defaults are display values. The update DTO accepts omitted classification, rejects explicit nulls and requires content when tags are supplied.
- **Impact.** Sending the whole form as a PATCH can reject unrelated edits or overwrite stored classification.
- **Solution.** Compare classification to the hydrated baseline after normalization and send only changed classification fields with the required title, description and code. Keep the response defaults usable in the form.
- **Implementation and verification.** See `toCourseDetailsUpdate` and `courseDetailsSchema` in `src/features/courses/course-details-schema.ts`. Verify that a legacy title-only edit omits both classification keys, a category-only edit sends only the category, a tag-only edit sends normalized comma-separated tags, and replacing existing classification with empty values fails validation.

## Batch multipart upload signing requests

**Verified** against the upload DTO and service and with a mocked 205-part upload. Live storage verification was unavailable.

- **Scenario and cause.** A multipart upload can exceed 100 parts, but the signing endpoint accepts at most 100 part numbers per request. Signing all parts together rejects otherwise valid large uploads.
- **Solution.** Request at most 100 URLs per batch, upload the batch using the plain storage client, and carry progress across batches. Complete the upload only after all parts succeed. See `uploadMultipartFile` in `src/services/upload.service.ts`.
- **Verification.** Assert batches of 100, 100 and 5 for 205 parts, sequential part order, progress reaching 100%, and no completion when a signed URL is missing.
