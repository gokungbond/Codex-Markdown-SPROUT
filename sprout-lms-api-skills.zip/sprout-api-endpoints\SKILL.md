---
name: sprout-api-endpoints
description: Implement or consume sprout-api HTTP endpoints, including CRUD routes, Swagger, list pagination, response serialization, and client request or response contracts.
---

# Sprout api endpoints

Before writing code, use the reference lookup in [AGENTS.md](../../../AGENTS.md#implementation-workflow) for the affected route, response contract or pagination behavior.

Read the neighboring controller, DTO, service, repository and entity. Use `src/modules/categories/controller/categories.controller.ts` for CRUD and `src/modules/courses/controller/courses.controller.ts` for a course-domain example. Follow the equivalent endpoint's verb, path, parameter names, status and permission. Common patterns are POST create (201), POST list with a body (200), GET detail, PATCH update and DELETE. Both 200 and 204 deletes exist, so verify the exact route. Keep custom actions explicit and check static paths against parameter routes.

Use a class DTO and Swagger decorators. Read `src/main.ts` for the production pipe and Swagger at /api/docs. Inspect guards and permissions before designing access. Keep Nest HTTP exceptions and shared response handling. `src/common/interceptors/response.interceptor.ts` wraps success as {success, statusCode, data, timestamp} and suppresses the body for 204. `src/common/filters/http-exception.filter.ts` emits {success, statusCode, message, error, path, timestamp}, with message sometimes an array. Entity instances support class serialization, including @Exclude in `src/modules/users/entities/user.entity.ts`. Preserve nested fields, date strings and numeric contracts. Prisma bigint fields may be stringified using `src/common/utils/serialized.ts`; check the actual transport type and avoid BigInt-to-Number precision loss.

For lists, check `src/common/dto/pagination-query.dto.ts` and the repository. Preserve {items, meta: {total, page, limit, totalPages}} where present. Use explicit filter/sort fields and retain stable ordering when changing offset pagination.

For a client or form integration, derive field names and required/null behavior from the DTO, send the route's documented body or query and a bearer access token when required, unwrap data only when a body exists, and handle HTTP/validation errors. Frontend component conventions belong to the frontend repository.

**Verify.** Exercise valid create/update/list/detail/delete as applicable, empty pages, not-found behavior, auth failures, validation errors and sensitive-field omissions through the production-equivalent HTTP stack.

- [ ] Route, Swagger and client agree on request and response shapes.
- [ ] Permissions, status codes and pagination remain compatible.
- [ ] 204 responses and nested serialization are covered where applicable.
