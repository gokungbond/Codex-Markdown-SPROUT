---
name: post-implementation-review
description: Review completed Sprout LMS API changes before handoff when they affect endpoints, business logic, data, access controls, sensitive information, or integrations. Use basic verification for behavior-preserving changes unless there is an identifiable security or data integrity risk.
---

# Post-implementation review

Run this review after implementation and before declaring the task complete. Apply it to changes in API endpoints, business rules, database operations, schema or migrations, authentication or authorization, security-sensitive functionality, sensitive data handling, third-party APIs, services or SDKs, S3 operations, transactions, concurrent workflows, and background jobs. Scale the depth and test evidence to the risks of the change.

For documentation, formatting, comments, namespace changes, and behavior-preserving internal restructuring, check the diff, scope, and affected references or tooling. For changed code, also check the [logical code separation convention](../sprout-backend-modules/SKILL.md#logical-code-separation). Review any identifiable security or data integrity risk even in these tasks.

## Review the implementation

Check logical code separation across every modified source and test file, including complete workflows and test scenarios that extend beyond the edited lines.

1. Read every changed and new task file. Compare the implementation with the requirements and trace the normal entry points and affected callers. Check controller, DTO, service, repository, entity, and Nest wiring using the applicable project skills. Use [endpoints](../sprout-api-endpoints/SKILL.md) and [validation](../sprout-request-validation/SKILL.md) for request and response shapes, status codes, errors, and runtime validation.
2. Check for defects, duplicate rules, avoidable complexity, and unintended behavior changes. For service and repository changes, inspect [BaseService](../../../src/common/database/base.service.ts) and [BaseRepository](../../../src/common/database/base.repository.ts). Confirm the implementation composes inherited operations where they fit and supplies the required owner, parent, and soft-delete predicates. Justify direct PrismaService use where the shared abstractions are unsuitable. Keep HTTP handling in controllers, business rules in services, and persistence in repositories. Use [backend modules](../sprout-backend-modules/SKILL.md) and [refactoring](../sprout-backend-refactoring/SKILL.md) for the implementation details.
3. Follow [Prisma data](../sprout-prisma-data/SKILL.md) and [data integrity](../sprout-data-integrity/SKILL.md) where relevant. Check query volume and growth for repeated lookups, unnecessary reads or writes, and N+1 queries. Check the affected invariants against actual constraints, including uniqueness, referential integrity, nullable fields, defaults, and soft deletes. Review migrations for existing-data compatibility and unintended loss. Trace transaction rollback, concurrent requests, duplicate delivery, idempotency, and partial external failures through to the final state.

Check the changed code for compliance with the [logical code separation convention](../sprout-backend-modules/SKILL.md#logical-code-separation). Refactor within the implementation only when the improvement is meaningful. Reuse existing code where it preserves semantics. Keep existing business rules and API contracts unless the task calls for a change. Keep new dependencies justified and schema changes within scope. Fix directly related findings within the authorized scope and recheck affected callers. For findings that require architectural changes or work outside scope, report the location, impact, and recommended fix.

## Review security and domain invariants

Use [API access](../sprout-api-access/SKILL.md) to trace authentication, effective route permissions, throttling, and resource scope. Confirm backend enforcement independent of client UI and validation. Check actor and parent scoping on reads and writes, explicit field mapping against mass assignment, parameterized queries, and safe handling of user content where clients render it. Check responses, logs, settings, and errors for excessive data, credentials, tokens, stack traces, or internal details. For integrations, validate outbound destinations and untrusted responses, including SSRF risk where inputs influence URLs, and check how errors, timeouts, and retries affect state.

- **Courses and learning resources.** Check access to restricted courses, lessons, assessments, videos, and downloads, including the delivery path. Verify enrollment and prerequisite rules, content-edit permissions, and server-controlled progress and completion where applicable.
- **Assessments and competencies.** Check that learner responses exclude answer keys before submission and that the server enforces submission eligibility and result ownership. Verify server-derived scores, competency levels and points, and that repeated submissions or retries cannot award credit twice.
- **S3 and file management.** Trace upload, download, streaming, or delete authorization through the storage adapter. Check owner and object-key binding, server-controlled keys, file type and size limits, private access, and signed URL operation and expiry. For multipart changes, check completion, abort, abandoned-upload cleanup, and recovery from partial failures without exposing credentials or unrelated objects.

## Verify

Use [testing procedures](../sprout-backend-testing/references/procedures.md) for focused Jest, HTTP or integration checks, non-emitting TypeScript, lint and build verification as applicable. Test the normal entry point for success, invalid input, failures, edge cases, denial and sensitive-field omissions. Where relevant verify persistence, rollback, duplicate prevention, concurrent requests, and third-party failures. Assert the resulting state as well as the response. Rerun affected checks after fixes or refactoring.

Use only authorized development or test environments. Verify both application and Prisma CLI targets before database-backed checks and use disposable MySQL. Stub external effects or use isolated test resources. Keep production data and infrastructure out of the review and avoid destructive database commands.

For an in-scope vulnerability or recurring bug, add focused regression coverage where appropriate and check the affected invariant at the lowest useful layer.

## Retain reusable findings

After verification, retain a vulnerability, recurring bug, data integrity issue, performance concern, or refactoring opportunity only when it can inform a future implementation or review. Skip trivial and isolated findings.

- Search relevant project references and existing notes in `AGENTS.md` by feature, symbol, invariant, and root cause. Update a matching entry in place and consolidate duplicates. Keep a single canonical entry under the skill responsible for the invariant. Use an existing reference if it fits. Create a focused file under that skill's `references/` only when needed and link it from the owning skill with a short cue for when to read it.
- Use a searchable heading and record the issue, root cause (or what remains unknown), applicable scenario, potential impact, recommended solution, implementation location or relevant source symbol, and verification method. Mark the solution **Verified** only when evidence supports it and cite the check and actual result. Use **Proposed** for an unverified recommendation and **Unresolved** when the cause or remediation is still open. Update outdated guidance when a better solution has been verified.
- Update project references as part of the workflow when a reusable finding has been verified. Retain a proposed or open finding only when the evidence and applicability make it useful for future work. Keep credentials, tokens, sensitive information, and personal data out of entries.
- Retain Sprout-specific implementation details in project references. Recommend a global skill update in the final report when the lesson generalizes to other projects. Modify a global skill only with explicit approval.

## Report

Summarize what changed, any refactoring, and security, integrity, or performance findings and fixes. Report the checks actually run and their results, skipped checks and reasons, and remaining risks or recommendations. Distinguish verified results from potential concerns and unverified assumptions. If the review finds no security issues, qualify that result to the reviewed scope.

Mention reference updates and any global skill recommendation when applicable.
