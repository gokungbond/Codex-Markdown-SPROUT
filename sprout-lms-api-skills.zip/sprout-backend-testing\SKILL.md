---
name: sprout-backend-testing
description: Plan and run sprout-api Jest unit, Nest HTTP feature, Supertest e2e, and Prisma/MySQL regression checks using repository-specific tooling.
---

# Sprout backend testing

Before writing code, use the reference lookup in [AGENTS.md](../../../AGENTS.md#implementation-workflow) for the affected test layer, fixture or regression scenario.

Read [procedures](references/procedures.md) for the exact commands and test database setup. Verify the affected module through the lowest useful test layer and its normal entry point. Capture a baseline, isolate side effects, and distinguish changed failures from existing ones. Report commands, scope and passed, failed, skipped or unavailable results.

- [ ] TypeScript and relevant formatting/lint checks completed.
- [ ] Applicable unit and HTTP/e2e checks completed.
- [ ] Input validation, auth and serialization checked.
- [ ] Persistence, rollback, duplicate prevention and ordering checked where relevant.
- [ ] Existing module and dependent behavior verified, including obvious N+1 risks.
- [ ] Test prerequisites and unverified paths reported.
