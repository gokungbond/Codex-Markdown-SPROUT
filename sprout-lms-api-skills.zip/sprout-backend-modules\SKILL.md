---
name: sprout-backend-modules
description: Build or maintain Sprout API NestJS modules, services, and repositories using shared base classes, dependency injection, and domain orchestration.
---

# Sprout backend modules

Before writing code, use the reference lookup in [AGENTS.md](../../../AGENTS.md#implementation-workflow) for the affected module, provider or shared base operation.

For any service or repository change, first read the shared [BaseService](../../../src/common/database/base.service.ts), [BaseRepository](../../../src/common/database/base.repository.ts), and [repository types](../../../src/common/database/base-repository.interface.ts). Then inspect an existing inheriting implementation. Start with [CoursesService](../../../src/modules/courses/service/courses.service.ts) and [CoursesRepository](../../../src/modules/courses/repository/courses.repository.ts), or choose a closer feature if its CRUD or query shape differs.

## Logical code separation

Prioritize readability so a reviewer can quickly understand what each block does and how the code flows from one step to the next.

Use this convention whenever you write, modify, or refactor code in this project, including production code, scripts, and tests. Group consecutive statements by what they accomplish. Add one blank line whenever the purpose changes, even between statements that use the same syntax or call the same dependency. Keep statements that accomplish a single step together. Follow the project's existing formatting standards.

In production code, separate initialization, retrieval, validation, business logic, persistence, and returns where they mark distinct steps. For example, in [course preview assignment](../../../src/modules/courses/service/courses.service.ts), keep upload checks together and put blank lines before S3 verification, before saving the association, and before returning the result. Keep a guard with its early return.

Apply the convention while writing code and verify it in every modified code file. Read each file in full, including surrounding code and complete workflows. Fix spacing gaps within the workflows being changed, even when the affected lines sit outside the original diff hunk.

For example, in [the course publication end-to-end test](../../../src/modules/courses/course-publication.e2e-spec.ts), separate the request helper, draft edit, resubmission and first approval, conflicting edit and rejected vote, and fetch and assertion of the still-published state. The edit and rejected vote stay together because they test one scenario. The public fetch and its matching assertions form the next block.

## Service and repository design

- Extend the corresponding base class by default. Match the generated Prisma model and where, create, update, order, select, and include types to the concrete repository and service. Inject the concrete repository into the service and pass it to `super(repository, 'EntityName')`. Inject `PrismaService` into the repository and pass the model delegate to `super(prisma.model)`. Keep concrete providers registered in Nest. A TypeScript interface alone supplies no runtime injection token.
- Keep DTO mapping, business rules, and orchestration in services. Compose with the protected `baseCreate`, `baseUpdate`, `baseRemove`, and `basePaginate` in feature methods. Use `findOneOrThrow` with the required scope. Use `baseRemove` for hard deletion and the repository's `softDelete` when the feature uses soft deletion.
- When a repository adds a method beyond the base repository API, create or update its module-specific contract under `interfaces/<module>-repository.interface.ts` and declare each added method there. For repositories that extend `BaseRepository`, extend `IBaseRepository` with the matching generic types so the contract inherits CRUD signatures. For standalone repositories, declare the operations they expose. Have the concrete repository implement the interface and keep Nest injection wired to the concrete provider. See [ICoursesRepository](../../../src/modules/courses/interfaces/courses-repository.interface.ts) for `findByUuid` and `paginateCourses`.
- Reuse inherited repository operations for CRUD, counts, pagination, and soft deletion. Add domain methods where the base API is insufficient. Prefer a scoped wrapper around an inherited method when it can express the query. CoursesRepository shows scoped `findUnique` with nested includes and `modulePagination` with filters. Check tenant or owner scope, soft-delete predicates, and return shape before reusing or overriding a method.

## Direct Prisma access

Keep Prisma calls in the repository layer. Use the model delegate or transaction client directly only when the inherited API cannot reasonably express the operation, such as a specialized query, aggregation, or transaction. Keep inheritance and scope direct access to the specialized method when ordinary CRUD still fits. [CourseActivitiesRepository](../../../src/modules/course-activities/repository/course-activities.repository.ts) inherits CRUD and uses the transaction client for scoped batch updates.

Use a standalone repository when the work falls outside the single-model base abstraction or extending it would add complexity, as in [LnaAssessmentsRepository](../../../src/modules/lna/repository/lna-assessments.repository.ts). A standalone orchestration service can compose repositories when ordinary CRUD is incidental. See [AuthService](../../../src/modules/security/auth/service/auth.service.ts). When using direct Prisma access in place of inherited operations, briefly record the operation and why the base API is unsuitable in the change summary. Leave a local comment if the reason would be hard to infer later.

## Module wiring

Trace HTTP, business rules, persistence, and tests before changing feature boundaries. Follow the neighboring module layout, register the module in [AppModule](../../../src/app.module.ts), and import or export providers through their owning modules. See [CompetenciesModule](../../../src/modules/competencies/competencies.module.ts) and check for circular dependencies.

For a new CRUD module, use `npm run module:generate -- FeatureName` (or `npm.cmd` on PowerShell) after confirming the pluralized destination is absent. The [generator](../../../src/cli/module-template/strategies/module-generator.ts) can remove the entire target module directory. Adapt the generated templates and verify provider wiring.

## Verification

- Run affected service and controller tests and the non-emitting typecheck. Follow the [testing procedures](../sprout-backend-testing/references/procedures.md).
- Exercise inherited behavior through the concrete service or repository. Assert mapped data, query scope, and error behavior at the affected entry point.
- For overrides and specialized methods, test changed behavior and retained caller expectations, including not-found, pagination, and soft-delete semantics when applicable. Use database-backed coverage for transaction or query behavior that mocks cannot verify.
- Confirm Nest resolves newly injected dependencies and check dependent call paths.
