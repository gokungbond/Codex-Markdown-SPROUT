---
name: sprout-api-access
description: Maintain authentication, permission checks, ownership scoping, and sensitive data boundaries in sprout-api endpoints.
---

# Sprout api access

Before writing code, use the reference lookup in [AGENTS.md](../../../AGENTS.md#implementation-workflow) for the affected guard, permission, actor or resource scope.

Inspect the guard order in `src/app.module.ts` and read `src/common/guards/jwt-auth.guard.ts`, `src/common/guards/roles.guard.ts`, `src/common/guards/account.guard.ts` and `src/common/decorators/roles.decorator.ts`. Authentication supplies the actor via JWT; authorization checks permission metadata and domain access separately. Handler-level @Roles([MODULES.X, PERMISSIONS.Y]) is the established permission convention, backed by `src/common/constants/permissions.constant.ts`. Inspect permission provisioning in `prisma/seed.ts` and the owning modules when adding capabilities. The role guard reads handler metadata, so check actual decorator placement. @Public is for intentionally public flows. AccountGuard enforces verified and active accounts.

Read `src/modules/security/auth/controller/auth.controller.ts`, `src/modules/security/auth/service/auth.service.ts` and `src/modules/security/auth/strategies/jwt.strategy.ts` for login/OTP, token rotation, password operations and actor claims. Use `src/common/decorators/current-user.decorator.ts` and scope persistence to the actor and parent when the domain requires it, as in `src/modules/upload/repository/upload.repository.ts`. Treat branch/organization scoping as feature-specific and verify rules in source. Use the existing throttling setup and inspect `src/modules/upload/controller/upload.controller.ts` for route-specific limits. Preserve key/ownership rules and the storage abstraction for files. Map writes explicitly and exclude confidential fields at serialization; use redacted logs.

**Verify.** Check anonymous, invalid/expired token, inactive and unverified accounts, permitted and denied actors and other-owner access as applicable. Cover token lifecycle, masked output and throttling for changes to those paths using isolated fixtures.

- [ ] Authentication, permission and record scope each match the contract.
- [ ] Server controls identity and sensitive fields.
- [ ] Denial cases leave persistent state unchanged.
