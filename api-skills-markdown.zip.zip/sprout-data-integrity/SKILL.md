---
name: sprout-data-integrity
description: Implement or diagnose sprout-api multi-write workflows, transactions, retries, concurrency, or idempotent and storage-backed state transitions.
---

# Sprout data integrity

Trace every read, write and external effect in the business operation. Identify the atomic invariant and which failures can occur before or after commit. Use `src/modules/course-activities/repository/course-activities.repository.ts` for an interactive transaction with course-scoped affected-row checks and `src/modules/lna/repository/lna-assessments.repository.ts` for an array transaction. For related ORM writes see `src/modules/course-assessments/service/course-assessments.service.ts` and its nested write shape.

Keep Prisma transaction wiring in the persistence layer. Inside a callback use the transaction client for all participating queries and let failures propagate to roll back. Prefer a scoped conditional update or a unique/composite constraint for races when it captures the invariant. Re-read and handle a competing winner only for an expected conflict. Choose locking or bounded retry only when the operation needs it and retries are safe. A read-only operation needs a transaction only when required by its consistency semantics.

Read `src/modules/upload/service/upload.service.ts`, `src/modules/upload/repository/upload.repository.ts` and `prisma/schema.prisma` for owner-scoped idempotency keys, state claims, conditional transitions and compensation around S3. Define terminal and retryable states and maintain ownership, persistent operation identifiers and required audit fields. Database rollback cannot undo storage or email. Keep network calls outside long-lived database transactions and plan compensation or reconciliation for partial failures. Use `src/common/storage/storage.service.ts` and `src/common/notifications/mailer/email.service.ts` for existing integrations. If proposing jobs/events, first verify a concrete delivery or retry need and the current checkout's infrastructure.

**Verify.** In disposable MySQL prove failed later writes roll back prior writes, wrong parent/owner is rejected, and repeated or concurrent calls preserve intended records and transitions. Stub remote effects and verify failure recovery without real uploads or emails.

- [ ] Atomic boundary and external failure handling are explicit.
- [ ] Retry and expected conflict handling preserve the invariant.
- [ ] Status transitions and audit fields are tested.
