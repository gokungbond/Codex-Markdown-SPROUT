---
name: sprout-api-state
description: Integrate Sprout LMS backend endpoints and manage Axios contracts, TanStack Query caches, authentication, and client state ownership.
---

# Sprout Api State

Use when adding or changing requests, paginated searches, mutations, auth-aware data, or synchronization between server and UI.

## Conventions and reference implementations

Before coding, search `references/reusable-findings.md` in this skill folder if it exists for the affected endpoint, session, cache or storage workflow. Check matching solutions against the current API contract and callers.

- Walk `src/types/api.ts` → domain contract → `src/services/category.service.ts` → `src/features/categories/hooks/use-categories.ts` or `src/features/categories/hooks/use-category-mutations.ts` → consuming page/dialog. Services use apiClient and unwrap res.data.data where the backend sends ApiSuccessResponse. List methods return items and meta for paginated contracts. Verify each endpoint's method, ID type, body vs params, and response envelope. Category list uses POST /categories/list. Preserve the real contract across services.
- `src/lib/axios.ts` reads NEXT_PUBLIC_API_URL (localhost:3001 fallback), attaches stored bearer tokens, retries eligible GET failures, and coordinates refresh across concurrent 401s. `src/lib/token-storage.ts`, `src/features/auth/hooks/use-current-user.ts`, and the auth/role guards in `src/components/common` implement client session behavior. Authorization is enforced by the backend. Follow `src/services/upload.service.ts` for application requests versus plain Axios presigned part uploads and never attach app credentials to storage requests.
- Define cache keys with `src/constants/query-keys.ts`. Include all request-defining inputs, gate details until the ID is usable, use existing list placeholder behavior deliberately, and trace every visible consumer before invalidating. `src/providers/query-provider.tsx` sets one-minute stale time, one retry, and no focus refetch. Course child hooks sometimes invalidate a child key while the parent uses its own course detail and explicit refetch via `src/features/courses/forms/course-form.tsx`. Check both before removing or adding refreshes.
- Convert zero-based table indexes to one-based API pages. Inspect last-page bounds for infinite queries. Several lookup hooks use an inclusive comparison that requests an extra page on the last known page, if backend metadata follows the paginated contract. For errors check `src/lib/on-error.tsx`, which handles string and array messages. Pending and success feedback belongs near the interaction.
- Keep server state in Query, field state in RHF, and transient UI state near its owner. Derive visible values instead of mirroring whole query responses. The course activities component holds a draft order of IDs over the server list. Check how a draft should reconcile on refresh, route/entity change, and save failure. Avoid broad effects and new state libraries. Memoize only for a concrete identity or computation requirement.

## Workflow and completion

1. Trace backend contract, current caller, keys, and auth context. Plan which readers refresh after a successful write and which state is intentionally local.
2. Reuse services and hooks. Verify payload mapping and envelope handling and avoid a duplicate fetch path. Check pagination/search changes and stale response behavior. Exercise pending, failure, retry, role/auth paths, and list/detail refresh. Check upload and protected paths only in an authorized local or test environment.
3. Run TypeScript and targeted ESLint via $sprout-quality. Confirm loading and error behavior, exact request, and no unnecessary fetch or double submit. Report changed files, reuse/refactoring, checks, and gaps.
