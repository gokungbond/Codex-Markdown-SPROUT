---
name: sprout-backend-modules
description: Build or reorganize NestJS modules and domain services in sprout-api, including dependency injection, shared CRUD, and cross-module orchestration.
---

# Sprout backend modules

Start at `src/app.module.ts` and the nearest module under `src/modules`. Use `src/modules/competencies/competencies.module.ts` for provider wiring and `src/modules/courses/courses.module.ts` for course-domain composition. Use `src/modules/lna/service/lna-assessments.service.ts` for actor-sensitive business rules and orchestration.

1. Trace an existing operation and its tests. Map HTTP, business decisions, persisted state and output before choosing boundaries.
2. For a new feature, follow the neighboring folder conventions (`controller`, `service`, `repository`, `dto`, `entities`, `interfaces`). Register the Nest module in AppModule. Import the owning module and export the required provider when another module consumes it. Check for circular imports before adding a dependency.
3. Use constructor injection and the existing concrete provider conventions. A TypeScript interface alone supplies no runtime injection token. Keep HTTP methods thin, use services for rules and orchestration, and put Prisma delegate operations in repositories. Generated Prisma types in services are common.
4. Reuse the protected CRUD helpers in `src/common/database/base.service.ts` and typed repository plumbing in `src/common/database/base.repository.ts` where the operation fits. For composed workflows use a plain injectable where it reads better, as in `src/modules/security/auth/service/auth.service.ts`. For genuinely substitutable completion checks see `src/modules/users/service/user-detail-checks/detail-completion.check.ts`.
5. The optional `npm.cmd run module:generate -- Example` generator is only for an absent destination. Review `src/cli/module-template/strategies/base-generator.ts` first because it recursively removes target subdirectories. Inspect generated files and wire imports and providers yourself.

**Verify.** Run the affected controller/service specs and the non-emitting typecheck from $sprout-backend-testing. A module compilation test should resolve every newly injected dependency.

- [ ] Module and providers resolve through normal app wiring.
- [ ] Rules remain with the owning domain and persistence stays in repositories.
- [ ] Existing callers and cross-module behavior are covered.
