---
name: sprout-architecture
description: Organize or extend Sprout LMS modules, App Router pages, layouts, navigation, and shared code.
---

# Sprout Architecture

Use when adding or restructuring a feature or deciding where a responsibility belongs.

## Conventions and reference implementations

Before coding, search `references/reusable-findings.md` in this skill folder if it exists for the affected route, module or shared boundary. Compare matching patterns with the current entry point and nearby modules.

- Next.js App Router owns route entry points in `src/app`. Check `src/app/admin/layout.tsx`, `src/app/dashboard/layout.tsx`, `src/components/layout/admin-shell.tsx`, and `src/constants/routes.ts` before adding protected navigation. The root layout composes `src/providers/app-providers.tsx`. Keep hook-driven components within a client boundary.
- `src/app/admin/categories/page.tsx` coordinates filters, pagination, columns, and dialog state. Its feature owns domain columns, schema, dialog, and hooks under `src/features/categories`. `src/features/users` is another small CRUD example. `src/features/courses` nests dialogs, child schemas, and form sections because it has separate workflows for modules, assessments, and resources.
- Put transport in `src/services`, backend contracts in `src/types`, feature validation/UI/hook logic in `src/features`, generic React hooks in `src/hooks`, and shared widgets in `src/components`. Search other callers before promoting code. Prefer a small feature slice with folders added as responsibilities grow.
- Use strict TypeScript and the `@/` alias across areas, with existing nearby relative imports where readable. Follow PascalCase components, camelCase hooks and functions, and kebab-case filenames. Use existing barrels where useful. Courses uses `hook` and some services use irregular filenames. Preserve those paths during ordinary feature work.
- Read README.md alongside current code. Its architectural overview predates some admin routes and modules.

## Workflow and completion

1. Trace route, shell, authorization, feature entry point, data and reusable dependencies. Compare a small CRUD module with the closest domain module.
2. Plan the smallest slice and its checks. Keep route orchestration, domain UI and transport responsibilities clear. Verify sidebar and route constants if navigation changes.
3. Review the diff, run the TypeScript check and ESLint, and smoke-test deep links, expected roles, narrow layout, and affected workflows when applicable. Use $sprout-quality for commands.
4. Confirm existing imports and contracts hold and reused code still works for its callers. Report changed files, reuse/refactoring, checks with outcomes, and remaining gaps.
