# Testing Sprout API

## Commands and scope

Run from the backend root. PowerShell examples use npm.cmd to avoid the npm.ps1 execution policy. On POSIX use npm.

```powershell
npm.cmd test -- --runInBand --runTestsByPath src/modules/lna/dto/create-lna-assessment.dto.spec.ts src/modules/lna/service/lna-assessments.service.spec.ts
npm.cmd test -- --runInBand
npm.cmd run test:cov -- --runInBand
& .\node_modules\.bin\tsc.cmd --noEmit --incremental false
& .\node_modules\.bin\tsc.cmd -p tsconfig.build.json --noEmit --incremental false
& .\node_modules\.bin\eslint.cmd src/modules/lna/dto/create-lna-assessment.dto.ts
& .\node_modules\.bin\prettier.cmd --check src/modules/lna/dto/create-lna-assessment.dto.ts
npm.cmd run test:e2e -- --listTests --runInBand
```

Substitute touched paths for ESLint and Prettier. The lint and format npm scripts modify files across the project. The build script calls cp for templates, which may require a POSIX shell on Windows. Jest unit settings are in `package.json` and HTTP e2e settings are in `test/jest-e2e.json`. ts-jest runs isolated transpilation with the current TypeScript config, so test execution does not replace the typecheck. Use `npm.cmd run prisma:generate` if the generated client is missing or out of date.

## Choose the right layer

- Pure calculation or strategy. Invoke with fixed inputs. Use table-driven normal, boundary and invalid cases, plus precision checks for numeric rules. Example: `src/modules/users/service/user-detail-checks/strategies/learning-needs-assessment.check.spec.ts`.
- Service. Use Nest TestingModule and useValue mocks for each current constructor dependency. Use `src/modules/lna/service/lna-assessments.service.spec.ts` for actor scope, valid writes and failed business invariants, and `src/modules/course-resources/service/course-resources.service.spec.ts` for integration-facing logic. Assert both the result and which writes happen or are skipped. Include missing dependencies, repeated requests and state-transition cases when relevant.
- DTO. Exercise the actual pipe, including class transformation, invalid/unknown keys and nested items. Example: `src/modules/lna/dto/create-lna-assessment.dto.spec.ts`.
- Controller. A direct call can assert argument forwarding. Use HTTP when testing route binding, pipes, guards or status/serialization behavior. Use `src/modules/competencies/competencies.e2e-spec.ts` for Supertest setup and tracked fixture cleanup and `src/modules/security/auth/auth.e2e-spec.ts` for overriding email providers. Inspect `src/main.ts` when preparing the Nest test app. Existing suites commonly set a validation pipe but do not automatically get bootstrap filters/interceptors. For production contracts explicitly configure matching validation, filters and serializer/interceptor order. Auth fixtures and response parsing in `src/common/utils/e2e-test.util.ts` assume a particular test setup; compare helpers against current auth routes and envelope before reuse.
- Real MySQL. Verify FK and unique constraints, nested relation and soft-delete behavior, transaction rollback and concurrency with disposable fixtures. Use independent requests for race tests and assert final database state as well as statuses. Mock S3/mail or use isolated test doubles when verifying failure recovery.

## HTTP and database setup

1. Review `src/config/env.validation.ts`, `src/prisma/prisma.service.ts`, `prisma.config.ts` and the suite's setup/cleanup. No dedicated e2e database override is wired into the script. NODE_ENV=test alone does not select an isolated database.
2. Set test environment values in the test process and verify the server/database against an explicitly disposable MySQL instance before migrations or test execution. Prisma CLI reads DATABASE_URL. App runtime prefers DATABASE_NAME/host/port/user/password if DATABASE_NAME is set, even if DATABASE_URL also exists. Check both and account for .env fallback. Use test-only signing secrets, isolated mail/storage settings and no real external destinations.
3. Apply existing migrations using `npm.cmd run prisma:deploy` on the verified disposable target. Seed only if the selected suite requires it. Use unique fixtures and remove only owned records in dependency order. Close the Nest app after each suite. Check throttling interactions when many requests share one client.
4. Run one suite first, for example `npm.cmd run test:e2e -- --runInBand --runTestsByPath src/modules/competencies/competencies.e2e-spec.ts`. Expand once isolation and teardown are verified. Report setup failures as such.

## Regression pass

Capture prior behavior and baseline results, add characterization cases where needed, implement the smallest change, then rerun targeted checks and dependent paths. Test success, invalid input, denied/unauthenticated access, not found, serialized fields, pagination/filtering, and precise status when relevant. For writes check committed rows, missing duplicates and rollback after an intermediate failure. For query changes verify representative row counts and query growth. Use the checklist in the parent skill and record results by command.

