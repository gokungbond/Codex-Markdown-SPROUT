---
name: sprout-quality
description: Validate Sprout LMS changes with repository TypeScript and ESLint commands and targeted browser regression checks.
---

# Sprout Quality

Use for test planning, validation, regression checks, or verifying refactors in Sprout.

## Code readability and logical separation

Prioritize readability. A reviewer should be able to tell what each block does and follow the code from one step to the next.

- Group consecutive statements by purpose. Add one blank line when the purpose changes, even when both blocks use the same kind of statement or call the same dependency.
- Separate initialization, data retrieval, validation, business logic, persistence, and returns where they form distinct steps.
- Keep closely related statements together. A guard belongs with its early return. In tests, keep an action with the assertions that verify it, and separate distinct stages or scenarios with a blank line.
- Follow the project's formatting conventions and avoid unnecessary blank lines.

Apply this convention while writing, modifying, or refactoring production code, scripts, and tests. During review, read every modified code file in full. Check the complete workflows and test scenarios affected by the change, including meaningful spacing boundaries outside the edited lines. Preserve behavior when making readability-only edits.

## Tooling and workflow

1. Read package.json, tsconfig.json, eslint.config.mjs, and the affected implementations. Select checks based on behavior and risk. Run npm run typecheck (use npm run typecheck -- --incremental false to avoid updating incremental state) and npm run lint. For focused lint pass explicit paths with npm run lint -- path/to/file. On Windows use npm.cmd if PowerShell blocks npm.ps1.
2. Inspect diagnostic paths. TypeScript includes generated .next types. If those fail to parse, establish whether the generated output or source caused the failure. Coordinate regeneration with any running dev server before touching generated outputs. ESLint config excludes generated output and `src/components/ui`; record scope and baseline findings. The `.husky/pre-commit` hook runs lint-staged, which can rewrite staged files. npm run format rewrites all source formatting.
3. Run npm run dev for local browser integration when a suitable API is available. README.md documents the companion backend, localhost defaults and environment variable. Check routes and client-only UI in a real browser. Use npm run build when validating a production compilation or route/build change. An available environment and test data are prerequisites for API-backed smoke checks.
4. The repo has no test script, checked-in unit/integration suite, or runner configuration. Record unit and integration automation as unavailable for the current checkout. Use targeted manual checks and, for pure transforms, evaluate actual functions or fixtures with available tooling when practical. If asked to add test infrastructure, propose a focused runner for mappers/schema and browser integration for critical workflows, with dependency changes scoped to the request.

## Regression matrix

- Forms and schemas. Exercise create, edit hydration, same-record reopen, switching records, dirty background refresh, optional/null/empty fields, nested errors, and exact submit shape. Use category, employee and course assessment workflows as representative examples.
- API and state. Check Network results for verb, path, payload, filtering and pagination, success/failure, pending and duplicate submits, and cache refresh for each affected reader. Use authorized local/test data for writes and verify permission behavior according to the affected workflow.
- Tables and shared components. Try deep links, narrow and wide layout, keyboard/focus, filter from later pages, last page, sorting and CSV scope, loading/empty/error, and another caller when a shared component changes.
- Refactor and transform checks. Compare before/after with representative fixtures, including legacy data, nulls, nested arrays, failures and retained callbacks/side effects. Verify the expected contract at its normal entry point.

## Completion

Review the diff and check existing imports, contract compatibility, intended loading and errors, and unrelated changes. Report files, reuse/refactoring, commands and outcomes, browser scenarios exercised, and gaps. Mark checks passed, failed, blocked, or not applicable based on execution.
