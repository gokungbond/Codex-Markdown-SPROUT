---
name: sprout-refactoring
description: Review or refactor Sprout LMS code while preserving behavior, API contracts, feature boundaries, and shared callers.
---

# Sprout Refactoring

Use for cleanup, consolidation, dead-code removal, or type-safety improvements in an existing Sprout feature. For reported bugs, trace the failure with $sprout-debugging first.

## Conventions and reference implementations

Before editing, search `references/reusable-findings.md` in this skill folder if it exists for the affected abstraction or behavior. Check matching solutions against current callers and regression coverage.

- Start with the actual problem. Compare `src/features/categories/hooks/use-category-mutations.ts` and `src/features/users/hooks/use-user-mutations.ts` for deliberate repetition with domain-specific payloads and keys. Keep small independent hooks when a shared factory would hide those contracts.
- Compare the employee form's section/dialog split in `src/features/employees/forms/employee-form.tsx` with the course module and assessment dialogs under `src/features/courses/dialogs`. Extract a named value or component when it makes dependencies, intent, or independent reuse clearer.
- Check current users of `src/components/tables/data-table.tsx`, `src/components/common/modal.tsx`, and shared inputs before changing their defaults or signatures. Search imports, barrels, call sites, and dynamic route references before removing code.

## Workflow and completion

1. Trace current behavior, data shapes, callbacks, effects, and error paths. Identify divergent callers before consolidating. Pin the contract and establish a before/after check.
2. Make the smallest effective change. Simplify naming and nesting, extract pure mapping or UI with a clear owner, and remove duplicate or derived state only after checking timing. Preserve public props, control modes, cache keys, endpoints, response and submit shapes, dismissal behavior, and null handling unless the task requires a change.
3. Check both direct and shared consumers, including pending/failure behavior, create/edit reopen, table pagination or course ordering where touched. Run $sprout-quality checks. Report scope, preserved contracts, reuse, actual results, and gaps.

## Refactoring candidates

- Low impact / low risk. Check the duplicate delete methods in `src/services/upload.service.ts` and their callers before consolidating.
- Medium impact / low to medium risk. Verify terminal page behavior in `src/features/users/hooks/use-users.ts` and analogous competency, position, and learning capability lookup hooks before aligning how they compute the next page.
- High impact / medium risk. Consolidate reset logic where edit input is vulnerable to incidental resets, starting with `src/features/categories/category-form-dialog.tsx` and `src/features/courses/dialogs/module/course-module-form-dialog.tsx`. Pin same-record reopen and selected-record transitions before changes.
- High impact / high risk. Inspect draft order reconciliation and overlapping refresh behavior across `src/features/courses/forms/components/course-activities-form.tsx` and `src/features/courses/forms/course-form.tsx`. Validate reorder/save, add/delete during a draft, server failures, and entity switches before changing the ownership model.
