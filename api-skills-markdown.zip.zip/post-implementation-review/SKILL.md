---
name: post-implementation-review
description: Review completed Sprout LMS SPA changes involving LMS API, third-party services or SDKs, AWS S3, or security-sensitive LMS workflows before declaring the task complete.
---

# Post-implementation review

Run after implementation for added or modified LMS API, third-party API, service or SDK integrations, S3 multipart uploads, signed URLs, downloads or streaming, and changes to authentication, authorization, course access, assessment integrity or sensitive user information. Use [sprout-quality](../sprout-quality/SKILL.md) for basic verification of presentation-only and internal component changes. Review any identifiable frontend security risk at the scope of that risk. Scale the depth to the affected boundaries and the impact of failure.

## Review the implementation

Read every changed and new file related to the task. Trace the normal App Router entry point through feature code, services, and types to the external boundary, then check affected shared callers. Confirm the requirements, project conventions, applicable skills, and existing behavior. Compare the request method, path, parameters, payload, response envelope and error handling against the backend controller, DTOs and response implementation, an authoritative API specification, or current provider documentation. Treat local types and mocks as client expectations. Record contract details that remain unverified.

Check for bugs, duplicated logic and unnecessary complexity. Use [sprout-api-state](../sprout-api-state/SKILL.md) for transport, session and cache conventions. Apply [sprout-refactoring](../sprout-refactoring/SKILL.md) when an in-scope change materially improves readability, reuse or ownership while preserving behavior and business rules. Prefer existing components, hooks, services and utilities. Leave code as-is when there is no meaningful improvement. Keep unrelated code and unjustified dependencies outside the review changes.

## Review the affected trust boundaries

- **Transport and session.** Trace changed requests through `src/lib/axios.ts`, `src/lib/token-storage.ts` and the auth or role guards as applicable. Check destinations and credential forwarding, refresh and request replay, stale session data, and exposure of tokens, secrets or personal data through browser storage, logs and errors.
- **Untrusted inputs and responses.** Check validation at the receiving boundary and how malformed or unexpected responses are handled. Follow third-party data into rendered content, URL attributes, redirects and SDK inputs such as the Video.js source in `src/features/courses/dialogs/module/video-player.dialog.tsx`. Check for injection, XSS, unsafe destinations and excessive data disclosure. Review duplicate writes, retries and races for inconsistent state.
- **Courses and assessments.** Inspect backend enforcement of roles, ownership, enrollment, prerequisites and access to courses, lessons, assessments, streams and downloads. Check that the backend enforces progress and completion rules, submission eligibility and uniqueness, and controls scores, competency levels and accumulated points. Check that responses exclude answers and sensitive evaluation data unless the caller is authorized to see them.
- **Storage.** Follow `src/services/upload.service.ts` and the affected upload or media consumer. The LMS client requests signed URLs and plain Axios sends multipart data to storage. Check that app credentials stay on the LMS requests, that signing scopes the object and operation with an appropriate expiry, and that private URLs and AWS credentials stay out of logs, persistent client storage and unnecessary responses. Check server-side ownership and file type and size rules, authorization for upload, download and deletion, and recovery from expiry, part failure, cancellation or interrupted completion. Check that retries and cleanup preserve files still in use.

Verify sensitive operations at the backend boundary using available server code, contracts or authorized test evidence. Frontend guards and validation are client behavior. Record unavailable enforcement evidence as an unverified security concern. For a confirmed issue that requires backend work outside the authorized scope, report the location, impact and recommended fix and leave backend changes for explicit approval.

## Verify the implementation

Use [sprout-quality](../sprout-quality/SKILL.md) to select repository checks, including relevant tests, lint, typecheck and build where applicable. Reuse applicable checks already run against the final implementation. Verify the real contract and exercise success, invalid input, failures and edge cases, including loading, error recovery, duplicate submission prevention, expired sessions, denied requests and unexpected responses when relevant. Recheck affected callers after review edits. Use authorized development or test environments and disposable data for write workflows. Avoid destructive tests and production data changes.

## Retain reusable findings

After verification, keep findings that can prevent a future vulnerability, recurring bug or data integrity failure, or guide a meaningful performance improvement or refactor. Skip trivial mistakes and isolated issues with no future application. Where appropriate, add a focused regression test for a discovered vulnerability or recurring bug within the authorized task scope, using existing test tools. Record a verification method and its limits when test coverage is unavailable.

Search the development guide, applicable skill guidance and relevant project references by symptom, component and root cause. Update the existing entry in its owning reference and consolidate duplicates. If there is no suitable entry, use `references/reusable-findings.md` under the skill that owns the implementation concern. Create the file only for a qualifying finding. Use a searchable heading and briefly record the issue, applicable scenario, root cause or current hypothesis, potential impact, recommended solution, implementation reference (file and symbol, when available), and verification method and actual result.

Update the project reference when a reusable finding is verified. Label solution status **Verified**, **Proposed**, or **Unresolved**, and state any evidence gaps. Replace outdated guidance when a better solution is verified. Keep entries free of credentials, tokens, signed URLs, personal data and other sensitive details. When the finding supports a universal engineering practice, recommend a global skill update in the final report. Global skill changes require explicit approval.

## Report

Summarize the implementation, review fixes, refactoring and any retained findings. Report security findings and their disposition, actual checks and outcomes, and unrun checks with reasons. Distinguish verified results, potential risks and unverified assumptions. If the review found no security issues, qualify that result by the scope reviewed.
