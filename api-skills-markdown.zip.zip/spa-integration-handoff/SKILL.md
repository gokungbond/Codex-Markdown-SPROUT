﻿---
name: spa-integration-handoff
description: After completing and reviewing an API implementation, assess its impact on a single-page application (SPA) and write a Markdown integration guide when SPA work is needed. Applies to observable contract and workflow changes. Skip backend-only changes.
---

# SPA Integration Handoff

## Decide whether the SPA needs work

After the API implementation and its review are complete, scan the implemented changes for SPA impact. Consider new SPA-facing features and routes, changes to methods, inputs, outputs, validation, authentication, permissions, filtering, search, sorting, pagination, and business rules or workflows. Generate a guide when the SPA needs to add or change a call, type, form, permission check, UI state, data refresh, or workflow.

If the change is internal and leaves SPA-facing behavior intact, stop without creating a guide. This includes internal refactors, schema and repository changes, performance work, and backend-only processes with no SPA impact. Limit the initial check to the changed feature and relevant shared API behavior.

## Verify the implemented contract

- Trace the affected routes, including effective path prefixes and methods, through controllers or handlers, request schemas, validation defaults and transformations, authentication and authorization, and business rules. Check response serialization, envelopes, status codes, and error handling. Use relevant tests and observed responses when available.
- For existing integrations, compare the previous and current behavior using the diff and affected call sites. If the SPA source is accessible and relevant, inspect its API client, types, forms, and workflows to identify concrete changes. Leave SPA files untouched.
- Treat plans and API descriptions as leads. Resolve discrepancies using the effective implementation. Flag unresolved requirements or unverified behavior explicitly. Use examples consistent with the verified contract and omit guessed fields or values.

## Write the handoff

Create a standalone Markdown file that the SPA coding agent can use directly. Use the requested destination or an established handoff location. If neither exists, save `<feature>-spa-integration.md` at the API workspace root and link it in the handoff. Keep the guide framework-independent and include only relevant sections.

- **Feature overview**. Explain what the feature does and when the SPA interacts with it.
- **API endpoints**. Give the method, effective URL, purpose, authentication, permissions, and route and query parameters. Include supported filter, search, sort, and pagination options.
- **Request payload**. Give field names and types, required and optional fields, accepted nulls, enum values, defaults, and representative examples. Explain omitted versus explicit null values where they differ.
- **Response payload**. Give successful status codes, response examples, field types, envelopes, pagination metadata, and empty or nullable results.
- **Validation and error handling**. Describe implemented limits and conditional requirements, relevant error statuses and shapes, and how the SPA should handle validation, access failures, and other verified errors.
- **Business rules and integration behavior**. Describe conditional actions, status and approval transitions, execution order, data dependencies and access restrictions, refresh or cache invalidation needs, and file upload, retrieval, and removal when relevant.
- **Existing integration impact**. Identify changes to API calls, payloads, types, services, forms, validation, and UI behavior. Distinguish new behavior from existing behavior and identify breaking changes.
- **Verification scenarios**. Cover the applicable success paths, validation and permission failures, edge cases, and regressions. Include migration or deployment prerequisites when they affect integration.

Before delivery, check every example and SPA action against the verified contract. Keep backend internals and frontend architectural preferences out of the guide unless they affect compatibility.
