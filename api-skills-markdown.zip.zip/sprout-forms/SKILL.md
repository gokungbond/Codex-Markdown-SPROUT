---
name: sprout-forms
description: Build or repair Sprout LMS React Hook Form workflows, Zod schemas, edit hydration, field arrays, and payload mappings.
---

# Sprout Forms

Use for create/edit forms, field validation, dependent inputs, or API-to-form normalization.

## Conventions and reference implementations

- For standalone create and edit pages, use `PageHeader` with a title, a short description of the form's purpose, and a visible “Back to [list]” action when the user can access the parent list. Link directly to the list route with `OutlineButton` and Next.js `Link` so the action also works from a direct URL. See `src/features/course-roadmaps/roadmap-form.tsx` and `src/features/courses/forms/components/header.tsx`.

Before coding, search `references/reusable-findings.md` in this skill folder if it exists for the affected hydration, validation or payload behavior. Compare matching solutions with the current form lifecycle and contract.

- Trace API response → form mapper → defaults/hydration → user interaction → Zod validation → submit mapper → API request. Compare `src/features/users/user-form-dialog.tsx` and `src/features/users/schemas.ts` for separate create/edit contracts, and `src/features/employees/forms/employee-form.tsx` for a mapper, nested address/contact arrays, and payload assembly. `src/features/categories/schema.ts` is a small schema example.
- Use `useForm` and `zodResolver` with the project's `src/components/forms/form.tsx` helpers and appropriate shared inputs. Pair fields with labels and messages. Check `src/components/common/app-form-select.tsx` and `src/utils/select-options.ts` before adding select adapters.
- Keep backend models, form shapes, and submit payloads explicit. Follow existing payload names and use `z.infer` for schema-derived values. If schema coercion or transforms change the type, distinguish Zod input from parsed output. Normalize nullable server values to controlled field defaults deliberately. Preserve meaningful false, zero, empty, null, and omission semantics. Map identifiers according to the contract, including IDs sent in URL paths.
- Compose nested schemas near the feature. `src/features/courses/dialogs/assessment/schemas/course-assessment-schema.ts` composes choice, question, and assessment schemas and checks for a correct answer. Assessment and question dialogs in that directory use `useFieldArray`. Prefer RHF field IDs for field-array render keys and retain backend UUIDs separately. Check that nested errors surface alongside the affected controls.

## Workflow and completion

1. Inspect mount behavior, open state, selected identity, query timing, and update contract. Plan hydration for record switches, late data, reopen, and background refetch. `src/components/common/modal.tsx` force-renders content. A reset tied only to entity object changes may miss same-record reopen or overwrite drafts on refresh.
2. Give every controlled field a suitable default. Reset a complete snapshot deliberately at the start of the form session or when its initial record becomes available. Keep user edits across unrelated renders. Avoid sequential resets like the category dialog's close path. Clear dependent values when the user actually changes their upstream value, and preserve valid dependencies during hydration. Use targeted RHF subscription or field events when needed.
3. Submit validated values via the feature mutation. Use the active create/update pending state, preserve input after errors, and close on success when appropriate. For course module upload, inspect `src/features/courses/dialogs/module/course-module-form-dialog.tsx` for existing upload UUID versus replacement handling and verify the upload plus metadata mutation as a single user flow.
4. Verify clean create, filled edit, cancel/reopen for the same and another record, delayed load, dirty refetch, conditional and array edits, invalid and valid submissions, exact payload, failure/retry, and duplicate-click behavior as applicable. Run targeted ESLint and TypeScript via $sprout-quality. Report files, reuse/refactoring, actual results, and gaps.
