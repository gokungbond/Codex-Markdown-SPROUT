---
name: sprout-backend-refactoring
description: Simplify or debug sprout-api backend code while preserving observable contracts, including duplicated business rules, broken orchestration, queries, and exceptions.
---

# Sprout backend refactoring

Capture the actual failure or duplication first. Trace the route, guards, normalized DTO, service rules, repository or external calls, and entity serialization. For a calculation compare inputs, normalization, precision and output. For unexpected model behavior check scoped relationships, generated client and soft deletes. For duplicate records or partial writes identify the ordering and atomic invariant. For integration failures trace storage/mail boundaries and state without logging secrets. Use the redacted Pino setup in `src/app.module.ts` and the 5xx handling in `src/common/filters/http-exception.filter.ts`.

Inspect callers and existing tests. Characterize current intended behavior before changing it. Candidates include duplicated sort-order lookup in `src/modules/course-modules/service/course-modules.service.ts` and `src/modules/course-assessments/service/course-assessments.service.ts`. Check the callers' null/initial-order behavior first. Extract a same-domain helper or repository query only when semantics match. Reuse `src/common/database/base.service.ts` and `src/common/database/base.repository.ts` if their scope and results fit. Keep feature-specific rules local. Prefer direct readable composition and remove dead code only after checking Nest registration, public routes and external callers. Shorter code is useful when it stays readable.

Compare before and after for status, error, payload, query scope, ordering, side effects and persisted state. For root-cause fixes where behavior must change, identify the intended difference and test it explicitly. Follow $sprout-backend-testing and report existing failures separately.

- [ ] Root cause or repeated invariant confirmed with evidence.
- [ ] Extraction reduces duplication without broadening behavior.
- [ ] Focused regression checks cover callers and failure paths.
