---
name: sprout-request-validation
description: Define or change sprout-api request DTOs, nested payloads, update semantics, and validation or mapping between HTTP requests and domain operations.
---

# Sprout request validation

Inspect `src/main.ts`, `src/modules/course-assessments/dto/create-course-assessment.dto.ts`, `src/modules/course-assessments/dto/question.dto.ts` and `src/modules/lna/dto/create-lna-assessment.dto.ts`. Global ValidationPipe transforms input, whitelists validated properties and rejects unknown keys. Preserve camelCase request fields. Describe required and optional fields in Swagger and validate with class-validator. Check whether omitted, null and empty have different meanings before using @IsOptional or a mapped partial DTO. Add explicit transformation where needed, as in `src/common/dto/pagination-query.dto.ts`. Validate nested arrays with @IsArray, @ValidateNested({ each: true }) and @Type, and check top-level array payloads through the LNA ParseArrayPipe example.

Use field decorators for format, length, range, enum and basic cross-field input invariants. Keep lookup, ownership, scoped existence, uniqueness and current-state rules in the service with repository support. `src/modules/lna/service/lna-assessments.service.ts` checks employee position and competency against stored state. Back durable uniqueness with the appropriate schema constraint; a preflight check alone can race. Use validated values to shape writes explicitly, especially actor, foreign keys, generated identifiers and nested relations.

Use DTO classes at the transport boundary. For service-to-service data, prefer the existing typed payload, interface or Prisma input when it describes the operation well. Add a dedicated DTO for a real transformation or independent contract. Preserve optional and nested semantics and avoid assuming DTOs are immutable.

**Verify.** Follow `src/modules/lna/dto/create-lna-assessment.dto.spec.ts` for table-driven bad-input checks. Assert errors for unknown fields, malformed nested elements and meaningful boundaries. Test business-rule failures separately in service specs and test numeric/date precision where the feature needs it.

- [ ] Swagger matches the runtime DTO and update semantics.
- [ ] Authenticated identity is server-derived.
- [ ] Boundary tests cover malformed input and invalid stored state.
