---
name: sprout-debugging
description: Diagnose Sprout LMS form resets, missing data, stale caches, validation errors, and unexpected client renders before fixing them.
---

# Sprout Debugging

Use when investigating a reported malfunction in Sprout. Use $sprout-quality for check commands.

## Reproduction and evidence

1. Capture route, role, relevant record ID, expected result, actual result, exact sequence, and timing. Reproduce with suitable local/test data. Inspect browser Console, Network, and Query Devtools from `src/providers/query-provider.tsx`. Use React DevTools/Profiler if available for render diagnosis.
2. Trace from the visible symptom back to its boundary. Compare the working nearest module before deciding whether behavior is an inconsistency or a domain constraint.
3. Implement the smallest verified root-cause fix. Remove temporary instrumentation and review the diff. Reproduce the original sequence plus a nearby success and failure path. Report cause, files, reuse/refactoring, actual checks, and gaps.

## Investigation paths

Before fixing the issue, search `references/reusable-findings.md` in this skill folder if it exists and check the relevant implementation skill's notes. Confirm that any matching root cause still explains the observed behavior.

- Missing or reset edit values. Start with `src/features/users/user-form-dialog.tsx` or `src/features/employees/forms/employee-form.tsx`. Compare API record, mapper result, form state before/after reset, open/record identity, conditional fields, and resolver output. For course module edit, inspect `src/features/courses/dialogs/module/course-module-form-dialog.tsx` and src/components/common/upload/file-upload.tsx for independent file state and upload UUID updates. The replacement handler can delete the old upload before submit. Exercise replace/cancel/reopen and failed replacement with authorized disposable data. Distinguish no data, remount, reset effect, field unregistering, and a resolver mismatch by observing when values first diverge.
- Empty table. Follow `src/app/admin/categories/page.tsx` through query params, HTTP envelope, items/meta and DataTable inputs. Check enabled state, zero-to-one page conversion, last-page bounds, filter/page reset, placeholder state, errors rendered as empty, and column accessors.
- Stale state or excess requests. Compare `src/constants/query-keys.ts`, the mutation invalidation, active observers and parent callbacks. In courses trace the detail query and child refreshes through `src/features/courses/forms/course-form.tsx`. For stale ordering, compare the local draft, payload in src/services/course-activity.service.ts, refreshed detail, and rendered order. Check whether a retained draft masks the fresh response or misplaces new IDs. Track identity changes, key-based remounts, refetches, RHF subscriptions and broad effects before adding memoization.
- Validation or request failures. Inspect actual values before validation, parsed values, field errors and request payload. Trace status and typed error envelope through `src/lib/axios.ts` and `src/lib/on-error.tsx`. Check disabled or pending controls and verify the mutation is reached only as intended. Avoid logging credentials, presigned URLs, or personal data.

## Completion

Verify the first divergence and expected recovery. Check related callers, no unexpected reset/request, and no duplicate submission where applicable. Run targeted ESLint and TypeScript and document any environment blocker.
