---
name: sprout-prisma-data
description: Change sprout-api Prisma models, migrations, relations, soft deletes, repository queries, pagination, or database performance.
---

# Sprout prisma data

Start with `prisma/schema.prisma`, `prisma.config.ts` and the affected SQL in `prisma/migrations`. Use the neighboring model's UUID or composite keys, *Uuid relation fields, mappings, column types, nullability and relation actions. MySQL and Prisma 7 are wired through the MariaDB driver adapter in `src/prisma/prisma.service.ts`. Treat generated artifacts under src/generated/prisma as build outputs.

1. Inspect existing data shape and callers before changing the schema. Add a forward migration for deployed changes. Stage required columns or tightened constraints with backfill and compatibility checks. Check duplicates and orphans before unique/FK additions. Review SQL for index coverage, locking, cascades and data loss. Plan rollback or compensating migrations and restore rehearsal where changes are irreversible.
2. Use `npm.cmd run prisma:migrate -- --create-only --name descriptive_name` only against a verified disposable dev database, then review the SQL and use the repository's migrate or deploy script as appropriate to the authorized target. Refuse any reset prompt on a database that must be kept. Run `npm.cmd run prisma:generate` after schema changes. Seed only when fixtures require it and the target is verified.
3. Use typed Prisma where/select/include at the repository. Reuse BaseRepository where it preserves semantics. Inspect `src/modules/course-assessments/repository/course-assessments.repository.ts` for nested includes and `src/modules/lna/repository/lna-assessments.repository.ts` for scoped selects. Soft delete is explicit, so check both top-level and nested relation filters. Use a scoped select or batched query for repeated lookups when measurements justify it; use aggregation for summary data.
4. Identify query count and representative parameters before optimizing. Compare row counts, ordering and execution plans on representative local/test data. Apply bounded batches for bulk jobs only when useful. Add cache only for measured needs with a clear invalidation contract. Put pagination search and preexisting OR predicates under an explicit AND if both must apply.

**Verify.** Typecheck after generation, run repository/feature tests on disposable MySQL, and rehearse migrations against fresh and existing-data cases. Verify filters, ties across pages, FKs/uniques, soft-delete visibility and query growth.

- [ ] SQL, existing-data compatibility and recovery reviewed.
- [ ] Query scope and result shape preserved.
- [ ] Schema, migrations and generated types agree.
